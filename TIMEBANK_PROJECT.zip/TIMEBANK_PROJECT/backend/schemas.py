from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    username: str
    password: str
    full_name: str
    email: str

class UserLogin(BaseModel):
    username: str
    password: str

class TaskCreate(BaseModel):
    title: str
    skill_name: Optional[str] = None
    description: str
    hours: float
    requester_id: int
    deadline: Optional[str] = None 

class ExchangeRequest(BaseModel):
    user_id: int
    amount: float
    action: str
    bank_info: Optional[str] = None

class ProfileUpdate(BaseModel):
    full_name: str
    email: str

class PasswordUpdate(BaseModel):
    current_password: str
    new_password: str

class UserOut(BaseModel):
    user_id: int
    username: str
    full_name: Optional[str]
    email: str
    balance_available: float
    is_admin: bool
    class Config:
        from_attributes = True