from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import models, schemas
from database import get_db

router = APIRouter(
    prefix="/api/exchange",
    tags=["Exchange"]
)

@router.post("/process")
def process_exchange(req: schemas.ExchangeRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == req.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Người dùng không tồn tại!")

    if req.action == "deposit":
        user.balance_available += req.amount
        change = req.amount
        a_type = "deposit"
    
    elif req.action == "withdraw":
        if user.balance_available < req.amount:
            raise HTTPException(status_code=400, detail="Số dư khả dụng không đủ!")
        user.balance_available -= req.amount
        change = -req.amount
        a_type = "withdraw"
    
    else:
        raise HTTPException(status_code=400, detail="Hành động không hợp lệ!")

    try:
        # Ghi nhật ký giao dịch
        new_history = models.TransactionHistory(
            user_id=user.user_id,
            hours_change=change,
            action_type=a_type
        )
        db.add(new_history)
        db.commit()
        db.refresh(user)
        return {"status": "success", "message": "Giao dịch thành công!", "balance": user.balance_available}
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Lỗi ghi lịch sử giao dịch!")