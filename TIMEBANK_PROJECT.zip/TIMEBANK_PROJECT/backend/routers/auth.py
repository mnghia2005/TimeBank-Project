from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_
from passlib.context import CryptContext
import models, schemas
from database import get_db

router = APIRouter(prefix="/api", tags=["Authentication"])

# Để cấu hình băm mật khẩu ở đây để các router khác (như user.py) có thể import dùng chung
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_password_hash(password): 
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password): 
    return pwd_context.verify(plain_password, hashed_password)

@router.post("/register")
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(or_(models.User.username == user.username, models.User.email == user.email)).first()
    if db_user: raise HTTPException(status_code=400, detail="Tài khoản hoặc Email đã tồn tại!")
    
    new_user = models.User(
        username=user.username,
        password=get_password_hash(user.password),
        full_name=user.full_name,
        email=user.email,
        balance_available=0.0,
        is_admin=False
    )
    db.add(new_user)
    db.commit()
    return {"status": "success", "message": "Đăng ký thành công!"}

@router.post("/login")
def login_user(user_credentials: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == user_credentials.username).first()
    
    # Kiểm tra mật khẩu bằng verify_password (so sánh plain với hash)
    if not user or not verify_password(user_credentials.password, user.password):
        raise HTTPException(status_code=400, detail="Thông tin đăng nhập không chính xác!")

    return {
        "status": "success", 
        "user_data": {
            "user_id": user.user_id,
            "username": user.username,
            "full_name": user.full_name,
            "balance": user.balance_available,
            "is_admin": user.is_admin
        }
    }