from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from database import get_db
import models

router = APIRouter(prefix="/api/admin", tags=["Admin"])

@router.get("/pending-deposits")
def get_pending_deposits(db: Session = Depends(get_db)):
    return db.query(models.TransactionHistory).options(joinedload(models.TransactionHistory.user)).filter(
        models.TransactionHistory.action_type == "deposit",
        models.TransactionHistory.status == "pending"
    ).all()

@router.post("/approve-deposit/{trans_id}")
def approve_deposit(trans_id: int, db: Session = Depends(get_db)):
    tx = db.query(models.TransactionHistory).filter(models.TransactionHistory.trans_id == trans_id).first()
    if not tx: raise HTTPException(status_code=404)
    user = db.query(models.User).filter(models.User.user_id == tx.user_id).first()
    user.balance_available += tx.hours_change
    tx.status = "success"
    db.commit()
    return {"message": "Duyệt nạp thành công!"}

@router.get("/pending-withdrawals")
def get_pending_withdrawals(db: Session = Depends(get_db)):
    return db.query(models.TransactionHistory).options(joinedload(models.TransactionHistory.user)).filter(
        models.TransactionHistory.action_type == "withdraw",
        models.TransactionHistory.status == "pending"
    ).all()

@router.post("/approve-withdrawal/{trans_id}")
def approve_withdrawal(trans_id: int, db: Session = Depends(get_db)):
    tx = db.query(models.TransactionHistory).filter(models.TransactionHistory.trans_id == trans_id).first()
    if not tx: raise HTTPException(status_code=404)
    user = db.query(models.User).filter(models.User.user_id == tx.user_id).first()
    user.balance_locked -= abs(tx.hours_change)
    tx.status = "success"
    db.commit()
    return {"message": "Đã xác nhận thanh toán!"}

@router.post("/reject-withdrawal/{trans_id}")
def reject_withdrawal(trans_id: int, db: Session = Depends(get_db)):
    tx = db.query(models.TransactionHistory).filter(models.TransactionHistory.trans_id == trans_id).first()
    if not tx: raise HTTPException(status_code=404)
    user = db.query(models.User).filter(models.User.user_id == tx.user_id).first()
    user.balance_available += abs(tx.hours_change)
    user.balance_locked -= abs(tx.hours_change)
    tx.status = "rejected"
    db.commit()
    return {"message": "Đã từ chối và hoàn lại tiền!"}

@router.get("/tasks")
def get_all_tasks(db: Session = Depends(get_db)):
    return db.query(models.Task).options(joinedload(models.Task.requester)).all()

@router.delete("/tasks/{task_id}")
def delete_task(task_id: int, db: Session = Depends(get_db)):
    db.query(models.Task).filter(models.Task.task_id == task_id).delete()
    db.commit()
    return {"message": "Đã xóa Task"}

@router.get("/users")
def get_all_users(db: Session = Depends(get_db)):
    return db.query(models.User).all()

@router.post("/users/{user_id}/toggle-admin")
def toggle_admin(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == user_id).first()
    if not user: raise HTTPException(status_code=404)
    user.is_admin = not user.is_admin
    db.commit()
    db.refresh(user)
    return {"message": "Cập nhật thành công", "is_admin": user.is_admin}