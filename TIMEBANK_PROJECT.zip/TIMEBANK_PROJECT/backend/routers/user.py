from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from datetime import datetime, timedelta

import models, schemas
from database import get_db
# Import bộ công cụ băm mật khẩu từ file auth để dùng chung
from routers.auth import verify_password, get_password_hash

router = APIRouter(prefix="/api", tags=["Users"])

@router.post("/exchange/process")
def process_exchange(req: schemas.ExchangeRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == req.user_id).first()
    if not user: raise HTTPException(status_code=404, detail="Người dùng không tồn tại!")
    if req.action == "deposit":
        new_tx = models.TransactionHistory(user_id=user.user_id, hours_change=req.amount, action_type="deposit", status="pending")
        db.add(new_tx); db.commit(); return {"message": "Yêu cầu nạp đã gửi thành công!"}
    elif req.action == "withdraw":
        if user.balance_available < req.amount: raise HTTPException(status_code=400, detail="Số dư khả dụng không đủ!")
        user.balance_available -= req.amount; user.balance_locked += req.amount
        if req.bank_info: user.bank_info = req.bank_info
        new_tx = models.TransactionHistory(user_id=user.user_id, hours_change=-req.amount, action_type="withdraw", status="pending")
        db.add(new_tx); db.commit(); return {"message": "Đã gửi yêu cầu rút. Giờ của bạn đang được tạm khóa chờ duyệt."}
    raise HTTPException(status_code=400, detail="Hành động không hợp lệ")

# --- API CẬP NHẬT HỒ SƠ ---
@router.put("/users/{user_id}/update-profile")
def update_profile(user_id: int, req: schemas.ProfileUpdate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == user_id).first()
    if not user: raise HTTPException(status_code=404)
    user.full_name = req.full_name
    user.email = req.email
    db.commit(); db.refresh(user)
    return user

# --- API ĐỔI MẬT KHẨU (ĐÃ FIX LỖI BẢO MẬT) ---
@router.put("/users/{user_id}/change-password")
def change_password(user_id: int, req: schemas.PasswordUpdate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == user_id).first()
    if not user: raise HTTPException(status_code=404)
    
    # FIX 1: Dùng verify_password để so sánh mật khẩu cũ (giữa chữ thuần và mã băm)
    if not verify_password(req.current_password, user.password):
        raise HTTPException(status_code=400, detail="Mật khẩu hiện tại không chính xác!")
    
    # FIX 2: Băm mật khẩu mới trước khi lưu vào Database
    user.password = get_password_hash(req.new_password)
    
    db.commit()
    return {"message": "Đổi mật khẩu thành công!"}

@router.get("/users/{user_id}")
def get_user_profile(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == user_id).first()
    if not user: raise HTTPException(status_code=404, detail="Không thấy người dùng")
    return user

@router.get("/dashboard/{user_id}")
def get_dashboard_data(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == user_id).first()
    if not user: raise HTTPException(status_code=404)
    total_income = db.query(func.sum(models.TransactionHistory.hours_change)).filter(models.TransactionHistory.user_id == user_id, models.TransactionHistory.hours_change > 0, models.TransactionHistory.status == "success").scalar() or 0.0
    pending_count = db.query(models.Task).filter(models.Task.requester_id == user_id, models.Task.status == "open").count()
    transactions = db.query(models.TransactionHistory).filter(models.TransactionHistory.user_id == user_id).order_by(models.TransactionHistory.transaction_date.desc()).all()
    history_list = []
    for tx in transactions:
        title, counterparty = "Hệ thống", "Hệ thống"
        if tx.task_id:
            task = db.query(models.Task).filter(models.Task.task_id == tx.task_id).first()
            if task: 
                title = task.title
                cp_user = db.query(models.User).filter(models.User.user_id == tx.counterparty_id).first()
                counterparty = cp_user.full_name if cp_user else "Thành viên"
        elif tx.action_type == "deposit": title = "Nạp giờ qua VietQR"
        elif tx.action_type == "withdraw": title = "Rút tiền về ngân hàng"
        history_list.append({"tx_id": tx.trans_id, "title": title, "counterparty": counterparty, "date": tx.transaction_date.strftime("%d/%m/%Y"), "full_time": tx.transaction_date.strftime("%H:%M:%S - %d/%m/%Y"), "amount": float(tx.hours_change), "type": tx.action_type, "status": tx.status})
    chart_labels, chart_income, chart_expense = [], [], []
    for i in range(6, -1, -1):
        date = (datetime.now() - timedelta(days=i)).date()
        chart_labels.append(date.strftime("%d/%m"))
        inc = db.query(func.sum(models.TransactionHistory.hours_change)).filter(models.TransactionHistory.user_id == user_id, models.TransactionHistory.hours_change > 0, func.date(models.TransactionHistory.transaction_date) == date, models.TransactionHistory.status == "success").scalar() or 0
        exp = db.query(func.sum(models.TransactionHistory.hours_change)).filter(models.TransactionHistory.user_id == user_id, models.TransactionHistory.hours_change < 0, func.date(models.TransactionHistory.transaction_date) == date, models.TransactionHistory.status == "success").scalar() or 0
        chart_income.append(float(inc)); chart_expense.append(abs(float(exp)))
    return {"balance": user.balance_available, "balance_locked": user.balance_locked, "total_income": round(total_income, 1), "pending_requests": pending_count, "recent_transactions": history_list, "chart": {"labels": chart_labels, "income": chart_income, "expense": chart_expense}}

@router.get("/transactions/all/{user_id}")
def get_all_transactions(user_id: int, db: Session = Depends(get_db)):
    txs = db.query(models.TransactionHistory).filter(models.TransactionHistory.user_id == user_id).order_by(models.TransactionHistory.transaction_date.desc()).all()
    res = []
    for tx in txs:
        title = "Nạp giờ" if tx.action_type == "deposit" else "Rút giờ" if tx.action_type == "withdraw" else "Hệ thống"
        if tx.task_id:
            task = db.query(models.Task).filter(models.Task.task_id == tx.task_id).first()
            title = task.title if task else "Công việc cũ"
        res.append({ "tx_id": tx.trans_id, "title": title, "date": tx.transaction_date.strftime("%d/%m/%Y"), "amount": float(tx.hours_change), "type": tx.action_type, "status": tx.status })
    return res