from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import models
from database import engine
from routers import auth, user, task, exchange, admin # THÊM ADMIN

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Time Bank API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(task.router)
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(exchange.router)
app.include_router(admin.router) # ĐĂNG KÝ ADMIN

@app.get("/")
def read_root():
    return {"status": "success", "message": "Server Admin Time Bank sẵn sàng!"}