document.getElementById('createTaskForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const userInfoStr = localStorage.getItem('user_info');
    if (!userInfoStr) {
        alert("Phiên làm việc hết hạn, vui lòng đăng nhập lại!");
        window.location.href = 'login.html';
        return;
    }
    const userInfo = JSON.parse(userInfoStr);

    const title = document.getElementById('taskTitle').value;
    const skills = document.getElementById('taskSkills').value;
    const hours = document.getElementById('taskCredit').value;
    const deadline = document.getElementById('taskDeadline').value;
    const description = document.getElementById('taskDescription').value;

    // Gói dữ liệu sạch: Không gộp Skills vào Description nữa
    const payload = {
        requester_id: userInfo.user_id,
        title: title,
        skill_name: skills, // Gửi riêng trường kỹ năng
        description: description, // Chỉ gửi mô tả thuần túy
        hours: parseFloat(hours),
        deadline: deadline ? deadline : null 
    };

    try {
        const btn = e.target.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Đang đăng bài...';

        const response = await fetch('http://localhost:8000/api/tasks/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (response.ok) {
            alert("Đăng yêu cầu thành công! Hệ thống đã tạm khóa " + hours + " giờ.");
            window.location.href = 'available_tasks.html';
        } else {
            alert("Lỗi: " + (result.detail || "Không thể tạo yêu cầu"));
            btn.disabled = false;
            btn.innerHTML = 'ĐĂNG YÊU CẦU NGAY';
        }
    } catch (error) {
        alert("Kết nối máy chủ thất bại!");
        console.error(error);
    }
});