document.addEventListener('DOMContentLoaded', function() {
    const userInfo = JSON.parse(localStorage.getItem('user_info'));
    if (!userInfo) { window.location.href = 'login.html'; return; }

    const rate = 100000; 
    const fee = 0.05;    
    
    const BANK_ID = "MB"; 
    const ACCOUNT_NO = "0987654321"; 
    const ACCOUNT_NAME = "TIME BANK SYSTEM"; 

    const qrModal = new bootstrap.Modal(document.getElementById('qrModal'));
    let pendingHours = 0;

    // 1. Tính toán thời gian thực
    document.getElementById('depositHours').addEventListener('input', function() {
        const hours = parseFloat(this.value) || 0;
        document.getElementById('depositAmount').innerText = (hours * rate).toLocaleString('vi-VN') + " ₫";
    });

    document.getElementById('withdrawHours').addEventListener('input', function() {
        const hours = parseFloat(this.value) || 0;
        const total = hours * rate * (1 - fee);
        document.getElementById('withdrawAmount').innerText = (total).toLocaleString('vi-VN') + " ₫";
    });

    // 2. Load số dư
    async function loadBalance() {
        try {
            const res = await fetch(`http://localhost:8000/api/users/${userInfo.user_id}`);
            const data = await res.json();
            document.getElementById('currentBalance').innerHTML = `${data.balance_available} <small class="fs-5 opacity-75">Giờ</small>`;
            document.getElementById('currentVnd').innerText = `Tương đương ≈ ${(data.balance_available * rate).toLocaleString('vi-VN')} VNĐ`;
        } catch (e) { console.error(e); }
    }

    // 3. Xử lý Nạp tiền
    document.getElementById('depositForm').onsubmit = function(e) {
        e.preventDefault();
        pendingHours = parseFloat(document.getElementById('depositHours').value);
        if (pendingHours <= 0) return;
        const amount = pendingHours * rate;
        const memo = `TB NAP ${userInfo.user_id}`;
        const qrUrl = `https://img.vietqr.io/image/${BANK_ID}-${ACCOUNT_NO}-compact.jpg?amount=${amount}&addInfo=${encodeURIComponent(memo)}&accountName=${encodeURIComponent(ACCOUNT_NAME)}`;
        document.getElementById('qrImage').src = qrUrl;
        document.getElementById('modalAmount').innerText = amount.toLocaleString('vi-VN') + " ₫";
        document.getElementById('modalMemo').innerText = memo;
        qrModal.show();
    };

    window.confirmDeposit = async function() {
        try {
            const res = await fetch('http://localhost:8000/api/exchange/process', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ user_id: userInfo.user_id, amount: pendingHours, action: 'deposit' })
            });
            if (res.ok) { alert("Yêu cầu nạp đã gửi! Vui lòng chờ Admin duyệt."); qrModal.hide(); loadBalance(); }
        } catch (e) { alert("Lỗi kết nối!"); }
    };

    // 5. Xử lý Rút tiền (Cập nhật: Gửi kèm Bank Info)
    document.getElementById('withdrawForm').onsubmit = async function(e) {
        e.preventDefault();
        const hours = document.getElementById('withdrawHours').value;
        const info = document.getElementById('bankInfo').value;

        const res = await fetch('http://localhost:8000/api/exchange/process', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ 
                user_id: userInfo.user_id, 
                amount: parseFloat(hours), 
                action: 'withdraw',
                bank_info: info // Gửi thông tin ngân hàng về server
            })
        });

        if (res.ok) { 
            alert("Lệnh rút đã gửi! Giờ của bạn đã được tạm khóa để chờ Admin duyệt."); 
            document.getElementById('withdrawForm').reset();
            loadBalance(); 
        } else {
            const err = await res.json();
            alert(err.detail);
        }
    };

    loadBalance();
});