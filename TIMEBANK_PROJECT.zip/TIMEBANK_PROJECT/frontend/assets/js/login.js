const loginForm = document.getElementById('loginForm');

loginForm.addEventListener('submit', async function(e) {
    // 1. Chặn form tự động load lại trang
    e.preventDefault();

    // 2. Lấy dữ liệu người dùng nhập
    const usernameInput = document.getElementById('username').value;
    const passwordInput = document.getElementById('password').value;

    // 3. Đóng gói dữ liệu chuẩn bị gửi đi
    const requestData = {
        username: usernameInput,
        password: passwordInput
    };

    try {
        // 4. Gọi API Backend (cổng 8000)
        const response = await fetch('http://localhost:8000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify(requestData) 
        });

        // 5. Đọc kết quả Backend trả về
        const result = await response.json();

        if (response.ok) {
            // CỰC KỲ QUAN TRỌNG: Lưu thông tin vào két sắt trình duyệt
            localStorage.setItem('user_info', JSON.stringify(result.user_data));
            
            alert(result.message); // Báo thành công
            
            // Chuyển hướng sang trang Dashboard
            window.location.href = 'dashboard.html'; 
        } else {
            // Báo lỗi sai pass/user
            alert("Lỗi: " + result.detail); 
        }

    } catch (error) {
        console.error("Lỗi mạng:", error);
        alert("Không thể kết nối đến Máy chủ. Vui lòng kiểm tra lại Backend!");
    }
});