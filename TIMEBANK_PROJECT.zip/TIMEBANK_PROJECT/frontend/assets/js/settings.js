document.addEventListener('DOMContentLoaded', async function() {
    const userInfo = JSON.parse(localStorage.getItem('user_info'));
    if (!userInfo) { window.location.href = 'login.html'; return; }

    async function loadCurrentData() {
        try {
            const res = await fetch(`http://localhost:8000/api/users/${userInfo.user_id}`);
            const data = await res.json();
            document.getElementById('username').value = data.username;
            document.getElementById('fullname').value = data.full_name;
            document.getElementById('email').value = data.email;
        } catch (e) { console.error(e); }
    }

    document.getElementById('profileForm').onsubmit = async function(e) {
        e.preventDefault();
        const updatedData = {
            full_name: document.getElementById('fullname').value,
            email: document.getElementById('email').value
        };

        try {
            const res = await fetch(`http://localhost:8000/api/users/${userInfo.user_id}/update-profile`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(updatedData)
            });

            if (res.ok) {
                const newUser = await res.json();
                userInfo.full_name = newUser.full_name;
                localStorage.setItem('user_info', JSON.stringify(userInfo));
                alert("Cập nhật hồ sơ thành công!");
            }
        } catch (e) { alert("Lỗi kết nối!"); }
    };

    document.getElementById('changePasswordForm').onsubmit = async function(e) {
        e.preventDefault();
        const currentPass = document.getElementById('currentPassword').value;
        const newPass = document.getElementById('newPassword').value;
        const confirmPass = document.getElementById('confirmNewPassword').value;

        if (newPass.length < 8) { alert("Mật khẩu mới phải từ 8 ký tự!"); return; }
        if (newPass !== confirmPass) { alert("Mật khẩu xác nhận không khớp!"); return; }

        try {
            const res = await fetch(`http://localhost:8000/api/users/${userInfo.user_id}/change-password`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ 
                    current_password: currentPass, // Khớp với Schema: current_password
                    new_password: newPass         // Khớp với Schema: new_password
                })
            });

            if (res.ok) {
                alert("Đổi mật khẩu thành công! Hãy thử đăng nhập lại bằng mật khẩu mới.");
                this.reset();
            } else {
                const err = await res.json();
                alert(err.detail || "Mật khẩu hiện tại không đúng!");
            }
        } catch (e) { alert("Lỗi kết nối!"); }
    };

    document.getElementById('btnLogout').onclick = () => { localStorage.clear(); window.location.href='login.html'; };
    loadCurrentData();
});