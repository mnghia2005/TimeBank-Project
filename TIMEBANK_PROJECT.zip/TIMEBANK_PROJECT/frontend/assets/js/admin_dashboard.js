document.addEventListener('DOMContentLoaded', function() {
    const userInfo = JSON.parse(localStorage.getItem('user_info'));
    
    if (!userInfo || !userInfo.is_admin) { 
        alert("Bạn không có quyền truy cập trang này!");
        window.location.href = 'dashboard.html';
        return; 
    }

    let allUsersCache = [];

    async function loadAllAdminData() {
        try {
            // 1. Load Duyệt nạp tiền
            const depRes = await fetch('http://localhost:8000/api/admin/pending-deposits');
            const deposits = await depRes.json();
            document.getElementById('listDeposits').innerHTML = deposits.length === 0 ? 
                '<tr><td colspan="4" class="text-center py-5 text-muted">Không có yêu cầu nạp.</td></tr>' :
                deposits.map(d => `
                <tr class="border-bottom">
                    <td class="ps-4 py-3"><strong>${d.user.full_name}</strong></td>
                    <td><span class="badge bg-primary bg-opacity-10 text-primary">+${d.hours_change}h</span></td>
                    <td class="small text-muted">${new Date(d.transaction_date).toLocaleString('vi-VN')}</td>
                    <td class="text-center"><button class="btn btn-success btn-sm rounded-pill px-3" onclick="approveDeposit(${d.trans_id})">Duyệt nạp</button></td>
                </tr>`).join('');

            // 2. Load Duyệt rút tiền (MỚI)
            const withRes = await fetch('http://localhost:8000/api/admin/pending-withdrawals');
            const withdrawals = await withRes.json();
            document.getElementById('listWithdrawals').innerHTML = withdrawals.length === 0 ? 
                '<tr><td colspan="4" class="text-center py-5 text-muted">Không có yêu cầu rút tiền nào.</td></tr>' :
                withdrawals.map(w => `
                <tr class="border-bottom">
                    <td class="ps-4 py-3"><strong>${w.user.full_name}</strong></td>
                    <td><span class="badge bg-danger bg-opacity-10 text-danger">${w.hours_change}h</span></td>
                    <td class="small"><code class="text-dark">${w.user.bank_info || 'Chưa cung cấp'}</code></td>
                    <td class="text-center">
                        <button class="btn btn-success btn-sm rounded-pill mb-1" onclick="approveWithdrawal(${w.trans_id})">Đã chuyển tiền</button>
                        <button class="btn btn-outline-danger btn-sm rounded-pill mb-1" onclick="rejectWithdrawal(${w.trans_id})">Từ chối</button>
                    </td>
                </tr>`).join('');

            // 3. Load Tasks
            const taskRes = await fetch('http://localhost:8000/api/admin/tasks');
            const tasks = await taskRes.json();
            document.getElementById('listTasks').innerHTML = tasks.map(t => `
                <tr class="border-bottom">
                    <td class="ps-4"><strong>${t.title}</strong></td>
                    <td class="small text-muted">${t.requester ? t.requester.full_name : 'N/A'}</td>
                    <td><span class="badge bg-secondary bg-opacity-10 text-secondary">${t.status.toUpperCase()}</span></td>
                    <td class="text-center"><button class="btn btn-outline-danger btn-sm rounded-pill px-3" onclick="deleteAdminTask(${t.task_id})">Xóa</button></td>
                </tr>`).join('');

            // 4. Load Users
            const userRes = await fetch('http://localhost:8000/api/admin/users');
            allUsersCache = await userRes.json();
            renderUserTable(allUsersCache);

        } catch (e) { console.error("Lỗi kết nối API Admin:", e); }
    }

    function renderUserTable(users) {
        const listUsr = document.getElementById('listUsers');
        listUsr.innerHTML = users.map(u => `
            <tr class="border-bottom">
                <td class="ps-4 py-3"><strong>${u.full_name}</strong> ${u.user_id == userInfo.user_id ? '<span class="badge bg-info text-white ms-1">Bạn</span>' : ''}</td>
                <td class="text-muted">${u.username}</td>
                <td class="fw-bold text-primary">${u.balance_available}h (🔒${u.balance_locked}h)</td>
                <td class="text-center">
                    <button class="btn ${u.is_admin ? 'btn-danger' : 'btn-outline-primary'} btn-sm rounded-pill px-3" 
                            onclick="toggleAdminStatus(${u.user_id})" 
                            ${u.user_id == userInfo.user_id ? 'disabled' : ''}>
                        ${u.is_admin ? 'Gỡ Admin' : 'Cấp Admin'}
                    </button>
                </td>
            </tr>`).join('');
    }

    // TÌM KIẾM USER
    document.getElementById('userSearchInput').addEventListener('input', (e) => {
        const keyword = e.target.value.toLowerCase();
        const filtered = allUsersCache.filter(u => 
            u.full_name.toLowerCase().includes(keyword) || 
            u.username.toLowerCase().includes(keyword)
        );
        renderUserTable(filtered);
    });

    // --- HÀNH ĐỘNG DUYỆT RÚT TIỀN ---
    window.approveWithdrawal = async (id) => {
        if(!confirm("Xác nhận bạn ĐÃ CHUYỂN KHOẢN tiền thật cho người dùng này?")) return;
        const res = await fetch(`http://localhost:8000/api/admin/approve-withdrawal/${id}`, {method: 'POST'});
        if(res.ok) { alert("Duyệt thành công!"); loadAllAdminData(); }
    };

    window.rejectWithdrawal = async (id) => {
        if(!confirm("Bạn muốn từ chối yêu cầu rút này? Giờ sẽ được trả lại ví cho User.")) return;
        const res = await fetch(`http://localhost:8000/api/admin/reject-withdrawal/${id}`, {method: 'POST'});
        if(res.ok) { alert("Đã từ chối!"); loadAllAdminData(); }
    };

    window.approveDeposit = async (id) => {
        const res = await fetch(`http://localhost:8000/api/admin/approve-deposit/${id}`, {method: 'POST'});
        if(res.ok) loadAllAdminData();
    };

    window.deleteAdminTask = async (id) => {
        if(!confirm("Xác nhận xóa?")) return;
        const res = await fetch(`http://localhost:8000/api/admin/tasks/${id}`, {method: 'DELETE'});
        if(res.ok) loadAllAdminData();
    };

    window.toggleAdminStatus = async (id) => {
        const res = await fetch(`http://localhost:8000/api/admin/users/${id}/toggle-admin`, {method: 'POST'});
        if(res.ok) loadAllAdminData();
    };

    loadAllAdminData();
});