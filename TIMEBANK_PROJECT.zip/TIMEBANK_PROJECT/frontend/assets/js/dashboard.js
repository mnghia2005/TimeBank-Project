document.addEventListener('DOMContentLoaded', async function() {
    let userInfo = JSON.parse(localStorage.getItem('user_info'));
    if (!userInfo) { window.location.href = 'login.html'; return; }

    // --- LOGIC ĐỒNG BỘ QUYỀN ADMIN ---
    async function syncAdminStatus() {
        try {
            const res = await fetch(`http://localhost:8000/api/users/${userInfo.user_id}`);
            const latest = await res.json();
            
            if (latest.is_admin !== userInfo.is_admin) {
                userInfo.is_admin = latest.is_admin;
                localStorage.setItem('user_info', JSON.stringify(userInfo));
            }

            if (userInfo.is_admin) {
                const nav = document.getElementById('sidebarNav');
                if (nav && !document.getElementById('adminNavItem')) {
                    const adminLi = document.createElement('li');
                    adminLi.id = 'adminNavItem';
                    adminLi.className = 'nav-item mt-3';
                    adminLi.innerHTML = `<a class="nav-link admin-link fw-bold" href="admin_dashboard.html">
                                            <i class="bi bi-shield-lock-fill me-3"></i>ADMIN PANEL
                                         </a>`;
                    nav.appendChild(adminLi);
                }
            }
        } catch (e) { console.error("Lỗi đồng bộ quyền:", e); }
    }

    document.getElementById('displayName').innerText = userInfo.full_name;
    let chartInstance = null;
    let allTxData = []; // Lưu trữ toàn bộ lịch sử để tìm kiếm và xem chi tiết

    // LOAD DỮ LIỆU TỪ BACKEND
    async function loadStats() {
        try {
            const res = await fetch(`http://localhost:8000/api/dashboard/${userInfo.user_id}`);
            const data = await res.json();
            document.getElementById('displayBalance').innerText = data.balance + "h";
            document.getElementById('displayIncome').innerText = data.total_income + "h";
            document.getElementById('displayPending').innerText = data.pending_requests;
            renderTable(data.recent_transactions);
            renderChart(data.chart);
        } catch (e) { console.error("Lỗi load Dashboard:", e); }
    }

    // BIỂU ĐỒ
    function renderChart(chartData) {
        const ctx = document.getElementById('myChart').getContext('2d');
        if (chartInstance) chartInstance.destroy();
        chartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [
                    { label: 'Thu nhập (+)', data: chartData.income, backgroundColor: '#10b981', borderRadius: 6 },
                    { label: 'Chi trả (-)', data: chartData.expense, backgroundColor: '#ef4444', borderRadius: 6 }
                ]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true, grid: { display: false } }, x: { grid: { display: false } } } }
        });
    }

    // BẢNG CHÍNH (7 DÒNG)
    function renderTable(txs) {
        const body = document.getElementById('tableBody');
        const displayTxs = txs.slice(0, 7);
        body.innerHTML = displayTxs.map(tx => `
            <tr class="cursor-pointer" onclick="showTxDetail('${tx.tx_id}')">
                <td class="py-3">
                    <div class="fw-bold text-dark">${tx.title}</div>
                    <div class="small text-muted">${tx.date}</div>
                </td>
                <td class="text-end fw-bold ${tx.amount > 0 ? 'text-success' : 'text-danger'}">
                    ${tx.amount > 0 ? '+' : ''}${tx.amount}h
                </td>
            </tr>`).join('');
    }

    // FIX LỖI: XEM CHI TIẾT (Tìm trong cả 2 nguồn: Dashboard data hoặc All history data)
    window.showTxDetail = async (txId) => {
        try {
            // Bước 1: Lấy dữ liệu mới nhất
            const res = await fetch(`http://localhost:8000/api/dashboard/${userInfo.user_id}`);
            const data = await res.json();
            
            // Bước 2: Tìm trong Recent trước, nếu không thấy thì tìm trong biến allTxData (lịch sử đầy đủ)
            let tx = data.recent_transactions.find(t => t.tx_id == txId);
            if (!tx && allTxData.length > 0) {
                tx = allTxData.find(t => t.tx_id == txId);
            }

            if (!tx) { alert("Không tìm thấy thông tin chi tiết!"); return; }

            const modalBody = document.getElementById('txDetailContent');
            modalBody.innerHTML = `
                <div class="bg-primary bg-opacity-10 p-4 rounded-circle d-inline-block mb-3"><i class="bi bi-clock-history fs-1 text-primary"></i></div>
                <h4 class="fw-bold text-dark mb-1">${tx.title}</h4>
                <p class="text-muted small">Mã GD: #TX-${tx.tx_id}</p>
                <div class="bg-light p-4 rounded-4 text-start mt-3">
                    <div class="mb-3"><label class="small text-muted fw-bold text-uppercase">Đối tác</label><p class="mb-0 fw-bold">${tx.counterparty || 'Hệ thống'}</p></div>
                    <div class="mb-3"><label class="small text-muted fw-bold text-uppercase">Số giờ thay đổi</label><p class="mb-0 fw-bold ${tx.amount>0?'text-success':'text-danger'}">${tx.amount>0?'+':''}${tx.amount} Giờ</p></div>
                    <div><label class="small text-muted fw-bold text-uppercase">Thời gian thực hiện</label><p class="mb-0 fw-bold">${tx.full_time || tx.date}</p></div>
                </div>`;
            
            // Hiển thị modal chi tiết (và tự động đóng modal danh sách nếu cần)
            new bootstrap.Modal('#txDetailModal').show();
        } catch (e) { console.error("Lỗi xem chi tiết:", e); }
    };

    // MỞ MODAL XEM TẤT CẢ
    window.openAllTransactions = async () => {
        try {
            const res = await fetch(`http://localhost:8000/api/transactions/all/${userInfo.user_id}`);
            allTxData = await res.json();
            renderAllTxTable(allTxData);
            new bootstrap.Modal('#allTransactionsModal').show();
        } catch (e) { console.error(e); }
    };

    // FIX LỖI: RENDER BẢNG TRONG MODAL (Đã thêm sự kiện Click và con trỏ)
    function renderAllTxTable(data) {
        const body = document.getElementById('allTxTableBody');
        body.innerHTML = data.map(tx => `
            <tr class="cursor-pointer" onclick="showTxDetail('${tx.tx_id}')">
                <td><strong>${tx.title}</strong><br><small class="text-muted">${tx.type.toUpperCase()}</small></td>
                <td class="fw-bold ${tx.amount>0?'text-success':'text-danger'}">${tx.amount>0?'+':''}${tx.amount}h</td>
                <td class="small text-muted">${tx.date}</td>
            </tr>`).join('');
    }

    // TÌM KIẾM TRONG MODAL (Đảm bảo ID searchTxInput hoạt động)
    const searchInput = document.getElementById('searchTxInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const key = e.target.value.toLowerCase();
            const filtered = allTxData.filter(tx => 
                tx.title.toLowerCase().includes(key) || 
                tx.type.toLowerCase().includes(key)
            );
            renderAllTxTable(filtered);
        });
    }

    document.getElementById('btnLogout').onclick = () => { localStorage.clear(); window.location.href='login.html'; };
    
    await syncAdminStatus();
    loadStats();
});