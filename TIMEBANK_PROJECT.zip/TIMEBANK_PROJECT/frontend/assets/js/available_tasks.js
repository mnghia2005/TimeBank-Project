document.addEventListener('DOMContentLoaded', async function() {
    const userInfo = JSON.parse(localStorage.getItem('user_info'));
    if (!userInfo) { window.location.href = 'login.html'; return; }

    const tableBody = document.getElementById('taskTableBody');
    const statusMessage = document.getElementById('statusMessage');
    const offcanvasEl = document.getElementById('taskDetailOffcanvas');
    const bsOffcanvas = new bootstrap.Offcanvas(offcanvasEl);
    
    let allTasks = [];

    // 1. Tải danh sách công việc
    async function fetchTasks() {
        try {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center py-5"><div class="spinner-border text-primary spinner-border-sm me-2"></div> Đang tải danh sách...</td></tr>';
            const response = await fetch(`http://localhost:8000/api/tasks/available/${userInfo.user_id}`);
            allTasks = await response.json();
            renderTable(allTasks);
        } catch (error) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-danger py-5"><i class="bi bi-exclamation-triangle me-2"></i> Lỗi kết nối máy chủ!</td></tr>';
        }
    }

    // 2. Hàm hiển thị bảng dữ liệu
    function renderTable(tasks) {
        tableBody.innerHTML = '';
        if (tasks.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-5">Chưa có công việc nào khả dụng.</td></tr>';
            return;
        }

        tasks.forEach(task => {
            const deadlineDate = task.deadline ? new Date(task.deadline).toLocaleDateString('vi-VN') : 'Không hạn';

            const row = document.createElement('tr');
            row.className = 'task-row';
            row.innerHTML = `
                <td class="py-4 ps-4" onclick="showDetail(${task.task_id})">
                    <div class="task-title mb-1 text-dark fw-bold">${task.title}</div>
                    <div class="text-muted small"><i class="bi bi-person-circle me-1"></i>${task.requester_name}</div>
                </td>
                <td><span class="badge-time">${task.hours} giờ</span></td>
                <td class="text-danger fw-medium small">${deadlineDate}</td>
                <td class="text-center">
                    <button class="btn-accept shadow-sm" onclick="handleAccept(${task.task_id})">
                        Nhận việc
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // 3. Hàm hiển thị Offcanvas chi tiết (Đã thêm Kỹ năng & Làm sạch mô tả)
    window.showDetail = function(taskId) {
        const task = allTasks.find(t => t.task_id === taskId);
        if (!task) return;

        const deadlineStr = task.deadline ? 
            new Date(task.deadline).toLocaleString('vi-VN', {hour: '2-digit', minute:'2-digit', day: '2-digit', month: '2-digit', year: 'numeric'}) : 
            'Không giới hạn thời gian';

        // LOGIC LÀM SẠCH DỮ LIỆU CŨ (Nếu lỡ còn rác [Skills: ...])
        let cleanDescription = task.description || 'Chưa cập nhật mô tả.';
        if (cleanDescription.includes('|')) {
            cleanDescription = cleanDescription.split('|').pop().trim();
        }

        const content = `
            <div class="mb-4">
                <p class="detail-label">Tiêu đề công việc</p>
                <h4 class="fw-bold mb-0 text-dark" style="letter-spacing: -0.5px;">${task.title}</h4>
            </div>
            
            <div class="row mb-4 g-3">
                <div class="col-6 text-center">
                    <div class="p-3 border rounded-3 bg-light">
                        <p class="detail-label mb-1">Mức thù lao</p>
                        <div class="fw-bold fs-5 text-primary">${task.hours} Giờ</div>
                    </div>
                </div>
                <div class="col-6 text-center">
                    <div class="p-3 border rounded-3 bg-light">
                        <p class="detail-label mb-1">Hạn chót</p>
                        <div class="fw-bold text-danger" style="font-size: 0.9rem;">${deadlineStr}</div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <p class="detail-label">Kỹ năng yêu cầu</p>
                <div class="p-3 rounded-3 border bg-white shadow-sm">
                    <div class="fw-bold text-dark"><i class="bi bi-tools text-secondary me-2"></i>${task.skill_name || 'Không yêu cầu kỹ năng cụ thể'}</div>
                </div>
            </div>

            <div class="mb-4">
                <p class="detail-label">Mô tả công việc (JD)</p>
                <div class="jd-box text-dark" style="white-space: pre-wrap;">${cleanDescription}</div>
            </div>

            <div class="p-3 rounded-3" style="background-color: #f0fdf4; border: 1px solid #dcfce7;">
                <p class="mb-0 small text-success text-center fw-medium">
                    <i class="bi bi-calendar-check me-2"></i> Ngày đăng bài: ${new Date(task.created_at).toLocaleDateString('vi-VN')}
                </p>
            </div>
        `;
        
        document.getElementById('offcanvasContent').innerHTML = content;
        document.getElementById('offcanvasFooter').innerHTML = `
            <button class="btn-accept w-100 py-3 fs-6 shadow" onclick="handleAccept(${task.task_id})">
                XÁC NHẬN NHẬN VIỆC NÀY
            </button>
        `;
        bsOffcanvas.show();
    };

    // 4. Xử lý nhận việc
    window.handleAccept = async function(taskId) {
        if (!confirm("Bạn có chắc chắn muốn nhận công việc này? Sau khi nhận, hãy liên hệ người đăng để bắt đầu.")) return;
        try {
            const response = await fetch(`http://localhost:8000/api/tasks/${taskId}/accept/${userInfo.user_id}`, {method: 'POST'});
            if (response.ok) {
                bsOffcanvas.hide();
                statusMessage.classList.remove('d-none');
                setTimeout(() => { 
                    statusMessage.classList.add('d-none'); 
                    fetchTasks(); 
                }, 2000);
            }
        } catch (error) { 
            alert("Lỗi kết nối máy chủ!"); 
        }
    };

    // 5. Logic Tìm kiếm
    document.getElementById('taskSearch').addEventListener('input', (e) => {
        const key = e.target.value.toLowerCase();
        const filtered = allTasks.filter(t => 
            t.title.toLowerCase().includes(key) || 
            (t.description && t.description.toLowerCase().includes(key)) ||
            (t.skill_name && t.skill_name.toLowerCase().includes(key)) ||
            t.requester_name.toLowerCase().includes(key)
        );
        renderTable(filtered);
    });

    fetchTasks();
});