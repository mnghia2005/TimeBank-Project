 // Chọn đúng cái form thông qua ID 
    const passwordForm = document.getElementById('changePasswordForm'); 
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmNewPassword');

    // Kiểm tra xem form có tồn tại không trước khi bắt sự kiện
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            // 1. Kiểm tra độ dài mật khẩu
            if (newPassword.value.length < 8) {
                e.preventDefault(); // Chặn không cho gửi form
                alert("Mật khẩu mới phải có ít nhất 8 ký tự!");
                newPassword.focus();
                return;
            }

            // 2. Kiểm tra mật khẩu mới và xác nhận có khớp nhau không
            if (newPassword.value !== confirmPassword.value) {
                e.preventDefault(); // Chặn không cho gửi form
                alert("Mật khẩu xác nhận không khớp. Vui lòng kiểm tra lại!");
                confirmPassword.focus();
                return;
            }

            // 3. Nếu mọi thứ ok
            alert("Chúc mừng! Mật khẩu đang được cập nhật...");
        });
    }