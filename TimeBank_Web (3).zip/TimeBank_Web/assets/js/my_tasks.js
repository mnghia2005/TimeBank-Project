 const tabButtons = document.querySelectorAll('button[data-bs-toggle="tab"]');
        tabButtons.forEach(btn => {
            btn.addEventListener('shown.bs.tab', function (e) {
                // Xóa style active ở tab cũ
                tabButtons.forEach(b => {
                    b.classList.remove('text-primary', 'border-bottom', 'border-primary', 'border-3');
                    b.classList.add('text-secondary', 'border-0');
                });
                // Thêm style active vào tab mới được chọn
                e.target.classList.remove('text-secondary', 'border-0');
                e.target.classList.add('text-primary', 'border-bottom', 'border-primary', 'border-3');
            });
        });