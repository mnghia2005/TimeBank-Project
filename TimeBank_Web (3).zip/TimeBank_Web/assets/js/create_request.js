 // Lấy thẻ form và khối thông báo
      const form = document.getElementById('createTaskForm')
      const statusMessage = document.getElementById('statusMessage')
      
      // Bắt sự kiện khi người dùng bấm nút "Gửi yêu cầu"
      form.addEventListener('submit', function (event) {
        // 1. Ngăn không cho trang web bị load lại (hành vi mặc định của form)
        event.preventDefault()
      
        // 2. Hiện thông báo "Tạo thành công!"
        statusMessage.classList.remove('d-none')
      
        // 3. Xóa trắng các ô nhập liệu để người dùng biết đã gửi xong
        form.reset()
      
        // 4. Tự động ẩn thông báo sau 3 giây
        setTimeout(() => {
          statusMessage.classList.add('d-none')
        }, 3000)
      })