 const acceptButtons = document.querySelectorAll('.btn-accept')
      const statusMessage = document.getElementById('statusMessage')
      
      acceptButtons.forEach((button) => {
        button.addEventListener('click', function () {
          this.innerHTML = '<i class="bi bi-check2"></i> Accepted'
          this.classList.remove('btn-outline-primary')
          this.classList.add('btn-success', 'text-white')
          this.disabled = true
      
          statusMessage.classList.remove('d-none')
          setTimeout(() => {
            statusMessage.classList.add('d-none')
          }, 3000)
        })
      })