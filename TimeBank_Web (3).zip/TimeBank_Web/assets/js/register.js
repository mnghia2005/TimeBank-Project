 const registerForm = document.getElementById('registerForm');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordError = document.getElementById('passwordError');

        // Bắt sự kiện khi người dùng bấm Submit
        registerForm.addEventListener('submit', function(event) {
            
            // So sánh 2 ô mật khẩu
            if (passwordInput.value !== confirmPasswordInput.value) {
                // 1. Chặn form không cho gửi đi
                event.preventDefault(); 
                
                // 2. Hiện câu thông báo lỗi màu đỏ lên
                passwordError.classList.remove('d-none');
                
                // 3. Đổi viền ô xác nhận thành màu đỏ cho nổi bật
                confirmPasswordInput.classList.add('is-invalid');
                
                // 4. Trỏ chuột (focus) tự động nhấp nháy lại vào ô xác nhận để người dùng gõ lại luôn
                confirmPasswordInput.focus();
            }
        });

        // Bắt sự kiện khi người dùng bắt đầu GÕ (input) lại vào ô Xác nhận mật khẩu
        confirmPasswordInput.addEventListener('input', function() {
            // Tự động ẩn lỗi và xóa viền đỏ đi cho giao diện sạch sẽ
            passwordError.classList.add('d-none');
            confirmPasswordInput.classList.remove('is-invalid');
        });