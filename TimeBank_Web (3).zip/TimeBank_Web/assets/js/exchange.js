// Thiết lập tỉ giá
const HOURLY_RATE = 100000; // 1 giờ = 100.000 VNĐ
const WITHDRAW_FEE = 0.05; // Phí rút 5%

// --- LOGIC NẠP GIỜ ---
const depositInput = document.getElementById('depositHours');
const depositAmount = document.getElementById('depositAmount');

depositInput.addEventListener('input', function() {
    // Lấy giá trị nhập vào, nếu trống thì mặc định là 0
    const hours = parseFloat(this.value) || 0;
    
    // Tính tiền
    const total = hours * HOURLY_RATE;
    
    // In ra màn hình với định dạng tiền tệ VNĐ
    depositAmount.textContent = total.toLocaleString('vi-VN') + ' ₫';
});


// --- LOGIC RÚT GIỜ ---
const withdrawInput = document.getElementById('withdrawHours');
const withdrawAmount = document.getElementById('withdrawAmount');
const balanceError = document.getElementById('balanceError');
const CURRENT_BALANCE = 150; // Giả lập số dư hiện tại của user là 150 giờ

withdrawInput.addEventListener('input', function() {
    const hours = parseFloat(this.value) || 0;
    
    // Kiểm tra xem có rút lố số dư không
    if (hours > CURRENT_BALANCE) {
        balanceError.classList.remove('d-none');
        this.classList.add('is-invalid');
        withdrawAmount.textContent = '0 ₫';
    } else {
        balanceError.classList.add('d-none');
        this.classList.remove('is-invalid');
        
        // Tính tiền sau khi trừ phí
        const total = hours * HOURLY_RATE * (1 - WITHDRAW_FEE);
        withdrawAmount.textContent = total.toLocaleString('vi-VN') + ' ₫';
    }
});


// --- LOGIC GỬI FORM (Giả lập) ---
document.getElementById('depositForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Đang chuyển hướng đến cổng thanh toán VNPay...');
});

document.getElementById('withdrawForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Chặn rút nếu bị lỗi lố số dư
    if (!withdrawInput.classList.contains('is-invalid')) {
        alert('Yêu cầu rút tiền đã được gửi. Hệ thống đang xử lý!');
        this.reset();
        withdrawAmount.textContent = '0 ₫';
    }
});