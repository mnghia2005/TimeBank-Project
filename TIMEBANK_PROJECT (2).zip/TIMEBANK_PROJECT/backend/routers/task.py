from fastapi import APIRouter, Depends, HTTPException, File, UploadFile # Thêm File, UploadFile
from sqlalchemy.orm import Session, joinedload
import models, schemas
from database import get_db
from datetime import datetime
import os
import uuid

router = APIRouter(
    prefix="/api/tasks",
    tags=["Tasks"]
)

# --- CẤU HÌNH LƯU TRỮ ẢNH MINH CHỨNG ---
UPLOAD_DIR = "static/evidence"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR, exist_ok=True)

# --- HÀM HỖ TRỢ: TỰ ĐỘNG HOÀN TIỀN CÁC TASK QUÁ HẠN (GIỮ NGUYÊN 100%) ---
def check_and_refund_overdue_tasks(db: Session):
    now = datetime.now()
    # Tìm các task đã qua deadline mà chưa hoàn thành (open, in_progress, waiting_confirmation)
    overdue_tasks = db.query(models.Task).filter(
        models.Task.deadline < now,
        models.Task.status.in_(["open", "in_progress", "waiting_confirmation"])
    ).all()

    for task in overdue_tasks:
        requester = db.query(models.User).filter(models.User.user_id == task.requester_id).first()
        if requester:
            # Hoàn trả từ ví khóa về ví khả dụng
            requester.balance_available += task.hours
            requester.balance_locked -= task.hours
        
        # Cập nhật trạng thái thành 'expired' (Hết hạn)
        task.status = "expired"
    
    if overdue_tasks:
        db.commit()

# 1. API: Tạo Task mới (GIỮ NGUYÊN)
@router.post("/")
def create_task(task: schemas.TaskCreate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.user_id == task.requester_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Không tìm thấy người dùng!")

    if user.balance_available < task.hours:
        raise HTTPException(status_code=400, detail=f"Số dư không đủ! Bạn cần {task.hours}h.")

    try:
        user.balance_available -= task.hours
        user.balance_locked += task.hours

        deadline_dt = None
        if task.deadline:
            deadline_dt = datetime.fromisoformat(task.deadline.replace('Z', '+00:00'))

        new_task = models.Task(
            title=task.title,
            skill_name=task.skill_name, 
            description=task.description,
            hours=task.hours,
            requester_id=task.requester_id,
            deadline=deadline_dt,
            status="open" 
        )
        db.add(new_task)
        db.commit()
        db.refresh(new_task)
        return {"status": "success", "message": "Đăng yêu cầu thành công!"}
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Lỗi hệ thống khi tạo task!")

# 2. API: Lấy danh sách việc khả dụng (GIỮ NGUYÊN + CẬP NHẬT TRẢ VỀ ẢNH)
@router.get("/available/{user_id}")
def get_available_tasks(user_id: int, db: Session = Depends(get_db)):
    check_and_refund_overdue_tasks(db)
    
    tasks = db.query(models.Task).options(joinedload(models.Task.requester)).filter(
        models.Task.status == "open",
        models.Task.requester_id != user_id
    ).all()
    
    return [
        {
            "task_id": t.task_id,
            "title": t.title,
            "skill_name": t.skill_name,
            "description": t.description,
            "hours": t.hours,
            "deadline": t.deadline.isoformat() if t.deadline else None,
            "created_at": t.created_at.isoformat(),
            "requester_name": t.requester.full_name if t.requester else "Ẩn danh",
            "evidence_image": t.evidence_image # Thêm để Frontend có thể hiển thị
        } for t in tasks
    ]

# 3. API: Chấp nhận nhận việc (GIỮ NGUYÊN)
@router.post("/{task_id}/accept/{provider_id}")
def accept_task(task_id: int, provider_id: int, db: Session = Depends(get_db)):
    check_and_refund_overdue_tasks(db)
    
    task = db.query(models.Task).filter(models.Task.task_id == task_id).first()
    if not task or task.status != "open":
        raise HTTPException(status_code=400, detail="Công việc không khả dụng hoặc đã hết hạn!")
    
    task.status = "in_progress"
    task.provider_id = provider_id
    db.commit()
    return {"status": "success", "message": "Nhận việc thành công!"}

# 4. API: Lấy việc TÔI ĐĂNG (GIỮ NGUYÊN + CẬP NHẬT TRẢ VỀ ẢNH)
@router.get("/my-posted/{user_id}")
def get_my_posted(user_id: int, db: Session = Depends(get_db)):
    check_and_refund_overdue_tasks(db)
    # Trả về kèm thông tin evidence_image để chủ bài đăng xem được minh chứng
    return db.query(models.Task).options(
        joinedload(models.Task.provider), 
        joinedload(models.Task.requester)
    ).filter(
        models.Task.requester_id == user_id,
        models.Task.status != "completed"
    ).all()

# 5. API: Lấy việc TÔI NHẬN (GIỮ NGUYÊN + CẬP NHẬT TRẢ VỀ ẢNH)
@router.get("/my-accepted/{user_id}")
def get_my_accepted(user_id: int, db: Session = Depends(get_db)):
    check_and_refund_overdue_tasks(db)
    return db.query(models.Task).options(joinedload(models.Task.requester)).filter(
        models.Task.provider_id == user_id,
        models.Task.status != "completed"
    ).all()

# --- 6. API: BÁO CÁO HOÀN THÀNH (NÂNG CẤP: NHẬN ẢNH MINH CHỨNG) ---
@router.post("/{task_id}/report-complete")
async def report_complete(task_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.task_id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Không tìm thấy task!")
        
    if task.status == "expired":
        raise HTTPException(status_code=400, detail="Công việc đã hết hạn, không thể báo cáo!")

    try:
        # Lưu file ảnh vào thư mục static/evidence
        file_ext = os.path.splitext(file.filename)[1]
        unique_filename = f"{uuid.uuid4()}{file_ext}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)
        
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)

        # Cập nhật trạng thái và lưu đường dẫn ảnh vào DB
        task.status = "waiting_confirmation"
        task.evidence_image = f"/static/evidence/{unique_filename}"
        db.commit()
        return {"message": "Đã gửi báo cáo kèm ảnh minh chứng!"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Lỗi khi lưu ảnh: {str(e)}")

# 7. API: Nghiệm thu & Ghi lịch sử (GIỮ NGUYÊN)
@router.post("/{task_id}/confirm-complete")
def confirm_complete(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.task_id == task_id).first()
    if not task: raise HTTPException(status_code=404)
    if task.status == "expired":
        raise HTTPException(status_code=400, detail="Công việc đã hết hạn và hoàn tiền!")
        
    owner = db.query(models.User).filter(models.User.user_id == task.requester_id).first()
    worker = db.query(models.User).filter(models.User.user_id == task.provider_id).first()
    try:
        owner.balance_locked -= task.hours
        worker.balance_available += task.hours
        task.status = "completed"
        h1 = models.TransactionHistory(user_id=owner.user_id, task_id=task.task_id, hours_change=-task.hours, counterparty_id=worker.user_id, action_type="transfer")
        h2 = models.TransactionHistory(user_id=worker.user_id, task_id=task.task_id, hours_change=task.hours, counterparty_id=owner.user_id, action_type="reward")
        db.add(h1); db.add(h2); db.commit()
        return {"status": "success", "message": "Nghiệm thu thành công!"}
    except Exception:
        db.rollback(); raise HTTPException(status_code=500, detail="Lỗi hệ thống!")

# 8. API: Hủy yêu cầu (GIỮ NGUYÊN)
@router.delete("/{task_id}/cancel")
def cancel_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.task_id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Không thấy công việc!")
        
    user = db.query(models.User).filter(models.User.user_id == task.requester_id).first()
    if task.status == "open":
        user.balance_locked -= task.hours
        user.balance_available += task.hours
        db.delete(task); db.commit()
        return {"message": "Đã hủy!"}
    raise HTTPException(status_code=400, detail="Không thể hủy!")