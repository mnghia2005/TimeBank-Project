from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles # THÊM DÒNG NÀY: Để xử lý file tĩnh
import models
from database import engine
from routers import auth, user, task, exchange, admin # GIỮ NGUYÊN ADMIN

# Khởi tạo Database (Giữ nguyên logic của Nghĩa)
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Time Bank API")

# --- QUAN TRỌNG: CẤU HÌNH ĐỂ HIỂN THỊ ẢNH MINH CHỨNG ---
# Dòng này giúp Frontend có thể truy cập vào folder static/evidence để xem ảnh
# Nếu không có dòng này, link ảnh sẽ báo lỗi 404
app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Đăng ký các Router - GIỮ NGUYÊN 100% thứ tự của Nghĩa
app.include_router(task.router)
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(exchange.router)
app.include_router(admin.router) # GIỮ NGUYÊN ADMIN

@app.get("/")
def read_root():
    return {"status": "success", "message": "Server Admin Time Bank sẵn sàng!"}