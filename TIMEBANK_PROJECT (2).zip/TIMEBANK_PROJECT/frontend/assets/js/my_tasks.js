document.addEventListener('DOMContentLoaded', function() {
    const userInfo = JSON.parse(localStorage.getItem('user_info'));
    if (!userInfo) { window.location.href = 'login.html'; return; }

    const postedTable = document.querySelector('#posted tbody');
    const acceptedTable = document.querySelector('#accepted tbody');
    const tabButtons = document.querySelectorAll('button[data-bs-toggle="tab"]');

    let postedTasksCache = [];
    let acceptedTasksCache = [];

    tabButtons.forEach(button => {
        button.addEventListener('shown.bs.tab', function (event) {
            tabButtons.forEach(btn => {
                btn.classList.remove('active', 'text-primary', 'border-bottom', 'border-primary', 'border-3');
                btn.classList.add('text-secondary', 'border-0');
            });
            event.target.classList.add('active', 'text-primary', 'border-bottom', 'border-primary', 'border-3');
            event.target.classList.remove('text-secondary', 'border-0');

            if (event.target.id === 'posted-tab') loadPostedTasks();
            if (event.target.id === 'accepted-tab') loadAcceptedTasks();
        });
    });

    const getStatusBadge = (status) => {
        const badges = {
            'open': '<span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-3">Đang tìm người</span>',
            'in_progress': '<span class="badge bg-info bg-opacity-10 text-info rounded-pill px-3">Đang làm</span>',
            'waiting_confirmation': '<span class="badge bg-warning text-dark rounded-pill px-3">Chờ xác nhận</span>',
            'expired': '<span class="badge bg-danger bg-opacity-10 text-danger rounded-pill px-3">Hết hạn</span>'
        };
        return badges[status] || status;
    };

    // --- NÂNG CẤP: HIỂN THỊ CHI TIẾT KÈM ẢNH MINH CHỨNG ---
    window.showDetail = (index, type) => {
        const task = type === 'posted' ? postedTasksCache[index] : acceptedTasksCache[index];
        const modalBody = document.getElementById('taskDetailContent');
        
        // Đoạn code kiểm tra nếu có ảnh thì hiển thị thêm một khu vực ảnh bên dưới
        let evidenceImageHtml = "";
        if (task.evidence_image) {
            evidenceImageHtml = `
                <div class="col-12 mt-3">
                    <label class="small text-muted fw-bold text-uppercase d-block mb-2 text-center">--- Ảnh minh chứng hoàn thành ---</label>
                    <div class="bg-white p-2 rounded-4 border shadow-sm text-center">
                        <img src="http://localhost:8000${task.evidence_image}" 
                             class="img-fluid rounded-3 shadow-sm" 
                             style="max-height: 350px; width: 100%; object-fit: contain;" 
                             alt="Minh chứng công việc">
                    </div>
                </div>
            `;
        }
        
        modalBody.innerHTML = `
            <div class="text-center mb-4">
                <div class="bg-primary bg-opacity-10 d-inline-block p-3 rounded-circle mb-3">
                    <i class="bi bi-file-earmark-text fs-2 text-primary"></i>
                </div>
                <h4 class="fw-bold text-dark mb-0">${task.title}</h4>
                <p class="text-muted small mt-1">Mã: #TB-${task.task_id}</p>
            </div>
            
            <div class="bg-light p-4 rounded-4 shadow-sm border">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="small text-muted fw-bold text-uppercase d-block mb-1">Người yêu cầu</label>
                        <p class="fw-bold text-dark mb-0"><i class="bi bi-person-fill me-2 text-primary"></i>${task.requester ? task.requester.full_name : 'N/A'}</p>
                    </div>
                    <div class="col-md-6">
                        <label class="small text-muted fw-bold text-uppercase d-block mb-1">Thời gian trao đổi</label>
                        <p class="fw-bold text-primary mb-0"><i class="bi bi-clock-fill me-2"></i>${task.hours} Giờ</p>
                    </div>
                    <div class="col-12">
                        <label class="small text-muted fw-bold text-uppercase d-block mb-1">Kỹ năng yêu cầu</label>
                        <p class="fw-bold text-dark mb-0"><i class="bi bi-tools me-2 text-secondary"></i>${task.skill_name || 'Không yêu cầu cụ thể'}</p>
                    </div>
                    <div class="col-12">
                        <label class="small text-muted fw-bold text-uppercase d-block mb-1">Mô tả chi tiết công việc</label>
                        <div class="p-3 bg-white rounded-3 border mt-2 text-dark" style="white-space: pre-wrap; font-size: 0.95rem; line-height: 1.6;">${task.description}</div>
                    </div>
                    ${evidenceImageHtml}
                </div>
            </div>
        `;
        const modal = new bootstrap.Modal(document.getElementById('taskDetailModal'));
        modal.show();
    };

    async function loadPostedTasks() {
        try {
            const res = await fetch(`http://localhost:8000/api/tasks/my-posted/${userInfo.user_id}`);
            postedTasksCache = await res.json();
            postedTable.innerHTML = postedTasksCache.length === 0 ? '<tr><td colspan="4" class="text-center py-5 text-muted">Chưa có yêu cầu nào được đăng</td></tr>' : 
            postedTasksCache.map((t, index) => `
                <tr class="align-middle border-bottom cursor-pointer hover-bg-light">
                    <td class="py-3 ps-3" onclick="showDetail(${index}, 'posted')">
                        <strong class="text-dark">${t.title}</strong><br>
                        <small class="text-primary">${t.hours} Giờ</small>
                    </td>
                    <td onclick="showDetail(${index}, 'posted')">${t.provider ? t.provider.full_name : '---'}</td>
                    <td onclick="showDetail(${index}, 'posted')">${getStatusBadge(t.status)}</td>
                    <td class="text-center">
                        ${t.status === 'waiting_confirmation' ? `<button class="btn btn-success btn-sm rounded-pill px-3 shadow-sm" onclick="confirmTask(${t.task_id})">Nghiệm thu</button>` : 
                          t.status === 'open' ? `<button class="btn btn-outline-danger btn-sm rounded-pill px-3 shadow-sm" onclick="cancelTask(${t.task_id})">Hủy</button>` : '---'}
                    </td>
                </tr>
            `).join('');
        } catch (e) { console.error(e); }
    }

    async function loadAcceptedTasks() {
        try {
            const res = await fetch(`http://localhost:8000/api/tasks/my-accepted/${userInfo.user_id}`);
            acceptedTasksCache = await res.json();
            acceptedTable.innerHTML = acceptedTasksCache.length === 0 ? '<tr><td colspan="4" class="text-center py-5 text-muted">Bạn chưa nhận công việc nào</td></tr>' :
            acceptedTasksCache.map((t, index) => `
                <tr class="align-middle border-bottom cursor-pointer hover-bg-light">
                    <td class="py-3 ps-3" onclick="showDetail(${index}, 'accepted')">
                        <strong class="text-dark">${t.title}</strong><br>
                        <small class="text-success">+${t.hours} Giờ</small>
                    </td>
                    <td onclick="showDetail(${index}, 'accepted')">${t.requester ? t.requester.full_name : 'N/A'}</td>
                    <td onclick="showDetail(${index}, 'accepted')">${t.deadline ? new Date(t.deadline).toLocaleDateString('vi-VN') : '---'}</td>
                    <td class="text-center">
                        ${t.status === 'in_progress' ? `<button class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm" onclick="reportComplete(${t.task_id})">Báo hoàn thành</button>` : getStatusBadge(t.status)}
                    </td>
                </tr>
            `).join('');
        } catch (e) { console.error(e); }
    }

    window.confirmTask = async (id) => { 
        if(confirm("Bạn xác nhận người làm đã hoàn thành tốt công việc và đồng ý chuyển trả số giờ tương ứng?")) { 
            await fetch(`http://localhost:8000/api/tasks/${id}/confirm-complete`, {method:'POST'}); 
            loadPostedTasks(); 
        } 
    };

    // --- NÂNG CẤP: CHỌN ẢNH KHI BÁO CÁO HOÀN THÀNH ---
    window.reportComplete = async (id) => {
        // Tạo một input file ẩn để mở hộp thoại chọn ảnh
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*'; // Chỉ nhận file ảnh

        fileInput.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Dùng FormData để gửi file qua Backend (multipart/form-data)
            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch(`http://localhost:8000/api/tasks/${id}/report-complete`, {
                    method: 'POST',
                    body: formData
                });

                if (res.ok) {
                    alert("Đã gửi báo cáo và ảnh minh chứng thành công!");
                    loadAcceptedTasks();
                } else {
                    const errData = await res.json();
                    alert("Lỗi: " + (errData.detail || "Không thể gửi báo cáo!"));
                }
            } catch (err) {
                console.error("Lỗi kết nối:", err);
                alert("Lỗi hệ thống khi tải ảnh lên!");
            }
        };

        if(confirm("Bạn xác nhận đã hoàn thành công việc và muốn gửi ảnh minh chứng?")) {
            fileInput.click();
        }
    };

    window.cancelTask = async (id) => { 
        if(confirm("Bạn chắc chắn muốn hủy yêu cầu này? Số giờ tạm khóa sẽ được hoàn trả lại ví của bạn.")) { 
            await fetch(`http://localhost:8000/api/tasks/${id}/cancel`, {method:'DELETE'}); 
            loadPostedTasks(); 
        } 
    };

    loadPostedTasks();
});